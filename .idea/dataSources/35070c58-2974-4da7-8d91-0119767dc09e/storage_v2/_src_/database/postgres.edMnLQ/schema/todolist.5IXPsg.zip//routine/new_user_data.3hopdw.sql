create function new_user_data() returns trigger
    language plpgsql
as
$$
DECLARE
	
	/* для хранения id вставленных тестовых данных - чтобы их можно было использовать при создании тестовых задач*/
	priorId1 INTEGER; 
	priorId2 INTEGER;
	priorId3 INTEGER;
	
	catId1 INTEGER;
	catId2 INTEGER;
	catId3 INTEGER;
	
	/* тестовые даты */
	date1 Date = NOW() + INTERVAL '1 day';
	date2 Date = NOW();
	date3 Date = NOW() + INTERVAL '6 day';

	/* ID роли из таблицы role_data */
	roleId INTEGER = 2;

BEGIN

	 /* при вставке нового пользователя - создаем строку активности */
    insert into todolist.activity (uuid, activated, user_id) values (gen_random_uuid (), 0, new.id);
    
	/* при вставке нового пользователя - создаем строку для хранения общей статистики - это не тестовые данные, а обязательные (иначе общая статистика не будет работать)*/
    insert into todolist.stat (completed_total, uncompleted_total, user_id) values (0,0, new.id);
    
	/* добавляем начальные тестовые категории для нового созданного пользователя */
    insert into todolist.category (title, completed_count, uncompleted_count, user_id) values ('Семья',0 ,0 ,new.id) RETURNING id into catId1; /* сохранить id вставленной записи в переменную */
    insert into todolist.category (title, completed_count, uncompleted_count, user_id) values ('Работа',0 ,0 ,new.id) RETURNING id into catId2;
	insert into todolist.category (title, completed_count, uncompleted_count, user_id) values ('Отдых',0 ,0 ,new.id) RETURNING id into catId3;
	insert into todolist.category (title, completed_count, uncompleted_count, user_id) values ('Путешествия',0 ,0 ,new.id);
    insert into todolist.category (title, completed_count, uncompleted_count, user_id) values ('Спорт',0 ,0 ,new.id);
    insert into todolist.category (title, completed_count, uncompleted_count, user_id) values ('Здоровье',0 ,0 ,new.id);



	/* добавляем начальные тестовые приоритеты для созданного пользователя */
    insert into todolist.priority (title, color, user_id) values ('Низкий', '#caffdd', new.id) RETURNING id into priorId1;
    insert into todolist.priority (title, color, user_id) values ('Средний', '#b488e3', new.id) RETURNING id into priorId2;
    insert into todolist.priority (title, color, user_id) values ('Высокий', '#f05f5f', new.id) RETURNING id into priorId3;



    	
	/* добавляем начальные тестовые задачи для созданного пользователя */
    insert into todolist.task (title, completed, user_id, priority_id, category_id, task_date) values ('Позвонить родителям', 0, new.id, priorId1, catId1, date1);
    insert into todolist.task (title, completed, user_id, priority_id, category_id, task_date) values ('Посмотреть мультики', 1,  new.id, priorId1, catId3, date2);
    insert into todolist.task (title, completed, user_id, priority_id, category_id) values ('Пройти курсы по Java', 0, new.id, priorId3, catId2);
    insert into todolist.task (title, completed, user_id, priority_id) values ('Сделать зеленый коктейль', 1, new.id, priorId3);
    insert into todolist.task (title, completed, user_id, priority_id, task_date) values ('Купить буханку хлеба', 0, new.id, priorId2, date3);

	/* по-умолчанию добавляем новому пользователю роль USER */
    insert into todolist.user_role (user_id, role_id) values (new.id, roleId);

	
	RETURN NEW;
END;
$$;

alter function new_user_data() owner to postgres;

